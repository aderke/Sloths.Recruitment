﻿namespace SlothEnterprise.ProductApplication.ServiceLocator
{
    public interface IProductProcessor
    {
        int ProcessProduct();
    }
}
