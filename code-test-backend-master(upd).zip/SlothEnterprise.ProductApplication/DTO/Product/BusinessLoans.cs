﻿namespace SlothEnterprise.ProductApplication.DTO.Product
{
    public class BusinessLoans : Product
    {       
        public decimal InterestRatePerAnnum { get; set; }
        
        public decimal LoanAmount { get; set; }
    }
}