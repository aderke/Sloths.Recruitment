﻿namespace SlothEnterprise.ProductApplication.DTO.Product
{
    public class SelectInvoiceDiscount : Product
    {
        public decimal InvoiceAmount { get; set; }
    }
}