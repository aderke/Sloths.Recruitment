﻿namespace SlothEnterprise.ProductApplication.DTO.Product
{
    public class ConfidentialInvoiceDiscount : Product
    {
        public decimal TotalLedgerNetworth { get; set; }
        public decimal AdvancePercentage { get; set; }      
    }
}