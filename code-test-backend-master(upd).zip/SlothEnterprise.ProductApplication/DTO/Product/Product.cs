﻿namespace SlothEnterprise.ProductApplication.DTO.Product
{
    public abstract class Product
    {
        public int Id { get; set; }
    }
}
